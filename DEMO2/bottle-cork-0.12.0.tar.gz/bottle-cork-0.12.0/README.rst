Cork - Authentication for the Bottle web framework

.. image:: https://secure.travis-ci.org/FedericoCeratto/bottle-cork.png?branch=master
   :target: http://travis-ci.org/FedericoCeratto/bottle-cork
   :alt: Build status

.. image:: https://coveralls.io/repos/FedericoCeratto/bottle-cork/badge.png?branch=master
   :target: https://coveralls.io/r/FedericoCeratto/bottle-cork?branch=master
   :alt: Coverage

.. image:: https://pypip.in/download/bottle-cork/badge.png
    :target: https://pypi.python.org/pypi//bottle-cork/
    :alt: Downloads

.. image:: https://pypip.in/version/bottle-cork/badge.png
    :target: https://pypi.python.org/pypi/bottle-cork/
    :alt: Latest Version

.. image:: https://pypip.in/license/bottle-cork/badge.png
    :target: https://pypi.python.org/pypi/bottle-cork/
    :alt: License



Cork provides a simple set of methods to implement Authentication and Authorization in web applications based on Bottle.

Website and Documentation:
  http://cork.firelet.net
